#coding=utf-8
from memory_alloction_ import get_memory_allocation
import random
import math
def add_noise(change_list,orig_list,index1,index2):
    (change_list[index1], change_list[index2]) = (orig_list[index2], orig_list[index1])

def tuihuo(o_1,pre_box_memory,append_limit,memory_reqquest_list,memory_reqquest_list_limit,all_hat_name):

    T0 = 1
    T_E = 0.5
    alpha = 0.9999
    best_severe_num = len(memory_reqquest_list)#最小箱子数
    markov = 10
    new_severe_num = best_severe_num
    T = T0
    floavor_dict = {
        "flavor1":[1,1],
         "flavor2":[1,2],
        "flavor3":[1,4],
        "flavor4":[2,2],
        "flavor5":[2,4],
        "flavor6":[2,8],
        "flavor7":[4,4],
        "flavor8":[4,8],
        "flavor9":[4,16],
        "flavor10":[8,8],
        "flavor11":[8,16],
        "flavor12":[8,32],
        "flavor13":[16,16],
        "flavor14":[16,32],
        "flavor15":[16,64]
    }
    predict_flavor_num_list= range(len(memory_reqquest_list))
    best_memory_reqquest_list = memory_reqquest_list[:]
    best_memory_reqquest_list_limit = memory_reqquest_list_limit[:]
    best_all_hat_name = all_hat_name[:]
    while T>T_E:
        for i in range(markov):
            random.shuffle(predict_flavor_num_list)
            change_index1,change_index2,change_index3,change_index4 = predict_flavor_num_list[:4]
            while memory_reqquest_list[change_index2]==memory_reqquest_list[change_index1] or \
                            memory_reqquest_list[change_index2]==memory_reqquest_list[change_index3] or\
                memory_reqquest_list[change_index3] == memory_reqquest_list[change_index1]:

                random.shuffle(predict_flavor_num_list)
                change_index1, change_index2, change_index3, change_index4 = predict_flavor_num_list[:4]
            # if memory_reqquest_list[change_index3] == memory_reqquest_list[change_index4]:
            #     continue
            change_memory_reqquest_list = memory_reqquest_list[:]
            change_memory_reqquest_list_limit = memory_reqquest_list_limit[:]
            change_all_hat_name = all_hat_name[:]
            o_1 = [0,1]
            random.shuffle(o_1)
            if o_1[0]:

                add_noise(change_memory_reqquest_list, memory_reqquest_list, change_index1, change_index2)
                add_noise(change_memory_reqquest_list_limit, memory_reqquest_list_limit, change_index1, change_index2)
                add_noise(change_all_hat_name, all_hat_name, change_index1, change_index2)
            else:
                o_1_2 = [0,1,2]
                random.shuffle(o_1_2)
                for i,o_ in enumerate(o_1_2):
                    change_memory_reqquest_list[predict_flavor_num_list[i]]  = memory_reqquest_list[predict_flavor_num_list[o_]]
                    change_memory_reqquest_list_limit[predict_flavor_num_list[i]]= memory_reqquest_list_limit[predict_flavor_num_list[o_]]
                    change_all_hat_name[predict_flavor_num_list[i]]= all_hat_name[predict_flavor_num_list[o_]]


            accury0 =0
            accury1 =0
            result,delet  = get_memory_allocation(o_1,pre_box_memory,append_limit,memory_reqquest_list,memory_reqquest_list_limit,all_hat_name)
            wuliji_num = len(result)#箱子数
            for i in result[-1]:
                accury0 += (floavor_dict[i][0])
                accury1 +=(floavor_dict[i][1])
            accury0 = accury0/float(pre_box_memory)#最后一个箱子所要优化的维度利用率
            accury1 = accury1/float(append_limit)#最后一个箱子另一个维度的利用率


            new_severe_num =  wuliji_num -1 + accury0
            print("best_severe_num:",best_severe_num)
            if new_severe_num < best_severe_num:
                best_severe_num = new_severe_num
                best_result = result[:]

                best_memory_reqquest_list = change_memory_reqquest_list[:]
                best_memory_reqquest_list_limit = change_memory_reqquest_list_limit[:]
                best_all_hat_name = change_all_hat_name[:]

                memory_reqquest_list = change_memory_reqquest_list[:]
                memory_reqquest_list_limit = change_memory_reqquest_list_limit[:]
                all_hat_name = change_all_hat_name[:]
            else:
                if random.random() < math.exp((best_severe_num - new_severe_num)/T ):

                    memory_reqquest_list = change_memory_reqquest_list[:]
                    memory_reqquest_list_limit = change_memory_reqquest_list_limit[:]

        T = T *alpha
    print (best_result)
    return best_result








