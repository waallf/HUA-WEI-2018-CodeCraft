# coding=utf-8
import sys
import os
import predictor
def main(k,threshold):
    ecsDataPath = sys.argv[1]
    inputFilePath = sys.argv[2]
    resultFilePath = sys.argv[3]
    predictor.predict_vm(ecsDataPath,inputFilePath,resultFilePath,k,threshold)
if __name__ == "__main__":
    dict_k = 6
    threshold = 2
    main(dict_k,threshold )
