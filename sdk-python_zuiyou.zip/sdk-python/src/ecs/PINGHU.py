#coding=utf-8
import math
def FF(arr):
    sum = 0
    res = []
    for a in arr:
        sum = sum + a
        res.append(sum)
    return res
def zhishupinghua(train_data, test_time, ALPP):
    sLI  =math.ceil(test_time/5.0)
    train_data = slice(train_data,sLI)
    train_data = FF(train_data)
    s1 = [0] * len(train_data)
    s2 = [0] * len(train_data)
    s3 = [0] * len(train_data)
    t = train_data
    s1[0] = t[1]
    for j in range(1, len(s1), 1):
        s1[j] = ALPP * train_data[j] + (1 - ALPP) * s1[j - 1]
    s2[0] = s1[1]
    for j in range(1, len(s2), 1):
        s2[j] = ALPP * s1[j] + (1 - ALPP) * s2[j - 1]
    s3[0] = s2[1]
    for j in range(1, len(s3), 1):
        s3[j] = ALPP * s2[j] + (1 - ALPP) * s3[j - 1]
    a = 3 * s1[-1] - 3 * s2[-1] + s3[-1]
    b = ALPP / (2.0 * (1 - ALPP) ** 2) * ((6 - 5 * ALPP) * s1[-1] - 2 * (5 - 4 * ALPP) * s2[-1] + (4 - 3 * ALPP) * s3[-1])
    c = ALPP ** 2 / (2 * ((1 - ALPP) ** 2)) * (s1[-1] - 2 * s2[-1] + s3[-1])
    Y1 = a + b + c
    sign =((sLI - 1) / sLI)
    yuce2 = (a + (2 + sign)* b + ((2 + sign)**2)* c)
    yuce = yuce2 - Y1
    yuce = round(yuce)
    if yuce < 0:
        yuce = 0
    yuce_flvorname_flavornum_s = int(yuce)
    return yuce_flvorname_flavornum_s
def preprocess(arr, N):
    N = int(N)
    t1 = len(arr) % N
    t2 = int(len(arr) / N)
    res = []
    for i in range(t2):
        temp = arr[t1 + N * i:t1 + N * i + N:1]
        res.append(sum(temp))
    return res
def slice(arr, N):
    arr = [0] + arr
    temp = preprocess(arr[1::1], N)
    return [0] +temp





if __name__ =="__main__":
    train_data =  [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];
    test_time = 7

    print(preprocess(train_data,test_time))

