from collections import Counter
def output_writer(all_flavor,predict_dic_flavor,result,need_xuniji_num,resultFilePath):
    file = open(resultFilePath,"w")
    result_list = []
    line_result = []
    for i in result:
        line_result.extend(i)
        result_list.append(dict(Counter(i)))
    line_result_dict = dict(Counter(line_result))
    # for k,v in line_result_dict.items():
    #     assert predict_dic_flavor[k] == v
    predict_dic_flavor = sorted(predict_dic_flavor.items(), key=lambda x: x[0])
    file.write(str(all_flavor) + "\n")
    [file.write(key+" "+str(value)+"\n") for (key,value) in predict_dic_flavor]
    file.write("\n")
    file.write(str(need_xuniji_num)+"\n")
    for index,i in enumerate(result_list):
        dict_i = dict(i)
        file.write(str(index+1))
        [file.write(" "+key + " " + str(value)) for  key, value in dict_i.items()]
        if index+1<len(result_list):
            file.write("\n")
