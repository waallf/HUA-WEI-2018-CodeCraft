#coding=utf-8
import math


 #要预测的时间点
def Markov(train_data,test_time):
    N = test_time
    Seq_Pre= 0
    
    Seq_Len = len(train_data)
    P_Order = max(train_data) +1
    Pi = [[0]*P_Order for i in range(P_Order)]
    for i in range(Seq_Len-1):
        Pi[train_data[i]][train_data[i+1]] = Pi[train_data[i]][train_data[i+1]] +1
    for i in range(P_Order):
        sum_Pri = sum(Pi[i])
        if sum_Pri !=0:
            Pi[i] = list(map(lambda x: x /float(sum_Pri),Pi[i]))
    S0 = [0] * P_Order
    S0[train_data[-1]]=1.5
    Sk = S0

    for k in range(N):
        m =0
        Sk_Pmax = []
        Sk = mat_mul(Sk, Pi)
        # while m < len(Sk) :
        #     try:
        #         Sk_index = Sk.index(max(Sk), m)
        #         m = Sk_index + 1
        #         Sk_Pmax .append(Sk_index)
        #     except:
        #         break
        #
        # Seq_Pre +=round(sum(Sk_Pmax)/float(len(Sk_Pmax)))
        Seq_Pre += round(sum(list(map(lambda x:x[0] *x[1],zip(range(P_Order),Sk)))))
    if Seq_Pre>0:
        Seq_Pre=Seq_Pre
    else:
        Seq_Pre+=2
    return int(Seq_Pre)

def mat_mul(li_st,mat_):
    SK= []
    mat_copy = mat_[:][:]
    mat_copy = (list(map(list, zip(*mat_copy))))#转置
    for line in mat_copy:
        SK .append(sum(list(map(lambda x:x[0] *x[1],zip(li_st,line)))))
    return SK


if __name__ =="__main__":
    train_data = [1,1,1,1,1,1,1,1]
    test_data = 3
    print(Markov(train_data,test_data))