#coding=utf-8
import math
import pymatrix

def fun_diff(T_D):
    return [T_D[i]- T_D[i-1] for i in range(1,len(T_D))]

def fluth_data(T_D):
    diff = fun_diff(T_D)
    diff_sum = sum(diff)
    diff_average = diff_sum/float(len(diff))
    diff_delta = math.sqrt(diff_delta)
    yuzhi_high = diff_average + 1.5 * diff_delta
    for i in range(0,len(T_D)-1):
        if T_D[i+1]-T_D[i]>yuzhi_high:
            T_D[i+1] = T_D[i]
    for i in range(len(T_D)-2,-1,-1):
        if (T_D[i] - T_D[i+1])>yuzhi_high:
            T_D[i] = T_D[i+1]
            for i in range(10):
                i =i
    return T_D

