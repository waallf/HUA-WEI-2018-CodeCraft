# -*- coding: UTF-8 -*-
import time
from fluth_data import fluth_data
def Read_Input_file(train_fileapth, input_filepath, threshold):
	
	# :param train_fileapth:训练文件名称
	# :param input_filepath: 测试文件名称
	# Flav_gjixing:[cpu num , mem num]
	# flavor_name"{"flavor" :[cpu_num,mem_num], ...}
	# cpu_mem :CPU OR MEM
	# L_list:训练数据
	# test_time:需要测试的时间长度

	data = open(input_filepath).readlines()
	Flav_gjixing = data[0].split()
	shuliang = int(data[2])
	flavor_name = {i.split(" ")[0]:[int(i.split(" ")[1].strip("\n")),int(i.split(" ")[2].strip("\n"))] for i in data[3:shuliang + 3]}

	cpu_mem = data[shuliang + 4].strip("\n").strip("\r")

	startTime = data[shuliang + 6].strip("\n").strip("\r").split(" ")[0]
	stopTime = data[shuliang + 7].strip("\n").strip("\r").split(" ")[0]

	S_Weekday,L_list = Read_train_F(train_fileapth, flavor_name, threshold, startTime)
	test_time = getday(startTime,stopTime) 
	S_T_W = date_change(startTime) % 7
	return Flav_gjixing,flavor_name,cpu_mem,L_list,test_time,S_Weekday,S_T_W


def Read_train_F(train_fileapth, flavor_name, threshold, startTime):
	data2 = open(train_fileapth).readlines()

	start = data2[0].split("\t")[2].strip("\n").strip("\r").split(" ")[0]
	S_Weekday = date_change(start) % 7

	stop = getday(start,data2[-1].split("\t")[2].strip("\n").strip("\r"))

	if getday(data2[-1].split("\t")[2].strip("\n").strip("\r"),startTime)!=1:
		stop = stop + getday(data2[-1].split("\t")[2].strip("\n").strip("\r"),startTime)-1
	print(stop)
	N = [[0] * (stop + 1) for x in xrange(len(flavor_name.keys()))]
	sumup = 0
	for j in data2:
		m = j.strip("\n").split("\t")
		try:
			mm = list(flavor_name.keys()).index(m[1])

			s = getday(start, m[2].strip("\r"))
			N[mm][getday(start,m[2].strip("\r"))] = N[mm][getday(start,m[2].strip("\r"))]+1
		except:
			continue
	for N_index,i in enumerate(N):
		i = quzao(i, threshold)  # 数据去噪
	return S_Weekday,N
def date_change(date):
	dd = 86400
	timeArray = time.strptime(date, "%Y-%m-%d")
	timeStamp = int(time.mktime(timeArray))
	return timeStamp/dd
#用于返回训练集的天数
def getday(start,stop):
	start= start.split(" ")[0]
	stop =  stop.split(" ")[0]
	S = date_change(start)
	E = date_change(stop)
	return E-S
def quzao(L, threshold):
	if len(L) - L.count(0) !=0:
		mean_incres = float(sum(L)- L[0])/(len(L) - L.count(0))
		for i in range(len(L)-1):
			if L[i + 1] - L[i] > mean_incres * threshold:
				L[i + 1] =  0
	return L







