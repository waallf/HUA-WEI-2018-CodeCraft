# coding=utf-8
__all__ = ['cross', 'dot', 'matrix', 'Matrix', 'MatrixError']
import fractions
import math
import operator
import functools

def matrix(*pargs, **kwargs):
    """ Convenience function for instantiating Matrix objects. """
    if isinstance(pargs[0], int):
        return Matrix.Identity(pargs[0]) # 
    elif isinstance(pargs[0], str):
        return Matrix.FromString(*pargs, **kwargs)
    elif isinstance(pargs[0], list):
        return Matrix.FromList(*pargs, **kwargs)
    else:
        raise NotImplementedError

def dot(u, v):
    return sum(map(operator.mul, u, v))
def cross(u, v):
    w = Matrix(3, 1)
    w[0][0] = u[1][0] * v[2][0] - u[2][0] * v[1][0]
    w[1][0] = u[2][0] * v[0][0] - u[0][0] * v[2][0]
    w[2][0] = u[0][0] * v[1][0] - u[1][0] * v[0][0]
    return w


class MatrixError(Exception):
    pass


class Matrix:
    def __init__(self, rows, cols, fill=0):
        self.nrows = rows
        self.ncols = cols
        self.grid = [[fill for i in range(cols)] for j in range(rows)]

    def __str__(self):
        maxlen = max(len(str(e)) for e in self)
        return '\n'.join(
            ' '.join(str(e).rjust(maxlen) for e in row) for row in self.grid
        )
    def __repr__(self):
        return '<%s %sx%s 0x%x>' % (
            self.__class__.__name__, self.nrows, self.ncols, id(self)
        )
    def __getitem__(self, key):
        return self.grid[key]
    def __contains__(self, item):
        for element in self:
            if element == item:
                return True
        return False
    def __neg__(self):
        return self.map(lambda element: -element)
    def __pos__(self):
        return self.map(lambda element: element)
    def __eq__(self, other):
        return self.equals(other, 0)
    def __ne__(self, other):
        return not self.__eq__(other)

    def __add__(self, other):
        if not isinstance(other, Matrix):
            raise MatrixError('cannot add %s to a matrix' % type(other))
        if self.nrows != other.nrows or self.ncols != other.ncols:
            raise MatrixError('cannot add matrices of different sizes')
        m = Matrix(self.nrows, self.ncols)
        for row, col, element in self.elements():
            m[row][col] = element + other[row][col]
        return m

    def __sub__(self, other):
        if not isinstance(other, Matrix):
            raise MatrixError('cannot subtract %s from a matrix' % type(other))
        if self.nrows != other.nrows or self.ncols != other.ncols:
            raise MatrixError('cannot subtract matrices of different sizes')
        m = Matrix(self.nrows, self.ncols)
        for row, col, element in self.elements():
            m[row][col] = element - other[row][col]
        return m

    def __mul__(self, other):
        if isinstance(other, Matrix):
            if self.ncols != other.nrows:
                raise MatrixError('incompatible sizes for multiplication')
            m = Matrix(self.nrows, other.ncols)
            for row, col, element in m.elements():
                for re, ce in zip(self.row(row), other.col(col)):
                    m[row][col] += re * ce
            return m
        else:
            return self.map(lambda element: element * other)

    def __rmul__(self, other):
        return self * other

    def __pow__(self, other):
        if not isinstance(other, int) or other < 1:
            raise MatrixError('only positive integer powers are supported')
        m = self.copy()
        for i in range(other - 1):
            m = m * self
        return m

    def __iter__(self):
        for row in range(self.nrows):
            for col in range(self.ncols):
                yield self[row][col]

    def heBing(self, other):
        if not isinstance(other, Matrix):
            raise MatrixError('cannot hebing %s from a matrix' % type(other))
        if self.nrows != other.nrows:
            raise MatrixError('cannot subtract matrices of different sizes')
        m = Matrix(self.nrows, self.ncols+other.ncols)
        for row, col, element in self.elements():
            m[row][col] = element
        for row, col, element in other.elements():
            m[row][col+self.ncols] = element
        return m

    def numberSubMatrix(self,number):
        m = Matrix(self.nrows, self.ncols)
        for row, col, element in self.elements():

            m[row][col] = number - element
        return m
        
    def numberMultiplyMatrix(self,number):
        m = Matrix(self.nrows, self.ncols)
        for row, col, element in self.elements():
            m[row][col] = number * element
        return m

    def subMatrix(self, row1,row2,col1,col2):
        m = Matrix((row2 - row1 + 1),(col2 - col1 + 1))
        
        for row in range(row1-1,row2,1):
            for col in range(col1-1,col2,1):
                m[row - row1 + 1][col - col1 + 1] = self[row][col]
        return m
    def shape(self):
        return [self.nrows,self.ncols]
    def row(self, n):

        for col in range(self.ncols):
            yield self[n][col]
    def rowAt(self, n):
        res = []
        for col in range(self.ncols):
            res.append(self[n-1][col])
        return res
    def colAt(self, n):
        res = []
        for row in range(self.nrows):
            res.append([self[row][n-1]])
        return res

    def cumsum(self):
        res=[]
        sum = self[0][0]
        for row in range(1,self.nrows):
            res.append(sum)
            sum = sum + self[row][0]
        res.append(sum)
        return res
    
    def col(self, n):
        for row in range(self.nrows):
            yield self[row][n]
    def rows(self):
        for row in range(self.nrows):
            yield self.row(row)

    def cols(self):
        for col in range(self.ncols):
            yield self.col(col)

    def rowvec(self, n):
        v = Matrix(1, self.ncols)
        for col in range(self.ncols):
            v[0][col] = self[n][col]
        return v

    def colvec(self, n):

        v = Matrix(self.nrows, 1)
        for row in range(self.nrows):
            v[row][0] = self[row][n]
        return v

    def equals(self, other, delta):

        if self.nrows != other.nrows or self.ncols != other.ncols:
            return False
        for row, col, element in self.elements():
            if not _equals(element, other[row][col], delta):
                return False
        return True

    def elements(self):

        for row in range(self.nrows):
            for col in range(self.ncols):
                yield row, col, self[row][col]

    def copy(self):

        return self.map(lambda element: element)

    def transpose(self):

        m = Matrix(self.ncols, self.nrows)
        for row, col, element in self.elements():
            m[col][row] = element
        return m

    def t(self):

        return self.transpose()

    def det(self):

        if not self.is_square():
            raise MatrixError('non-square matrix does not have determinant')
        ref, _, multiplier = _get_row_echelon_form(self)
        ref_det = functools.reduce(
            operator.mul, 
            (ref[i][i] for i in range(ref.nrows))
        )
        return ref_det / multiplier

    def minor(self, row, col):

        return self.del_row_col(row, col).det()

    def cofactor(self, row, col):

        return pow(-1, row + col) * self.minor(row, col)

    def cofactors(self):

        m = Matrix(self.nrows, self.ncols)
        for row, col, element in self.elements():
            m[row][col] = self.cofactor(row, col)
        return m

    def adjoint(self):

        return self.cofactors().transpose()

    def inverse(self):

        if not self.is_square():
            raise MatrixError('non-square matrix cannot have an inverse')
        rref, inverse = _get_reduced_row_echelon_form(
            self, Matrix.Identity(self.nrows)
        )
        if rref != Matrix.Identity(self.nrows):
            raise MatrixError('matrix is non-invertible')
        return inverse

    def del_row_col(self, row_to_delete, col_to_delete):

        return self.del_row(row_to_delete).del_col(col_to_delete)

    def del_row(self, row_to_delete):

        m = Matrix(self.nrows - 1, self.ncols)
        for row, col, element in self.elements():
            if row < row_to_delete:
                m[row][col] = element
            elif row > row_to_delete:
                m[row - 1][col] = element
        return m

    def del_col(self, col_to_delete):

        m = Matrix(self.nrows, self.ncols - 1)
        for row, col, element in self.elements():
            if col < col_to_delete:
                m[row][col] = element
            elif col > col_to_delete:
                m[row][col - 1] = element
        return m

    def map(self, func):

        m = Matrix(self.nrows, self.ncols)
        for row, col, element in self.elements():
            m[row][col] = func(element)
        return m

    def rowop_multiply(self, row, m):

        for col in range(self.ncols):
            self[row][col] = self[row][col] * m

    def rowop_swap(self, r1, r2):
        """ In-place row operation. Interchanges the two specified rows. """
        for col in range(self.ncols):
            self[r1][col], self[r2][col] = self[r2][col], self[r1][col]

    def rowop_add(self, r1, m, r2):

        for col in range(self.ncols):
            self[r1][col] = self[r1][col] + m * self[r2][col]

    def ref(self):

        return _get_row_echelon_form(self)[0]

    def rref(self):

        return _get_reduced_row_echelon_form(self)[0]

    def len(self):

        return math.sqrt(sum(e ** 2 for e in self))

    def dir(self):

        return (1 / self.len()) * self

    def is_square(self):

        return self.nrows == self.ncols

    def is_invertible(self):
        try:
            inverse = self.inverse()
            return True
        except MatrixError:
            return False

    def rank(self):
        rank = 0
        for row in self.ref().rows():
            for element in row:
                if element != 0:
                    rank += 1
                    break
        return rank

    @staticmethod
    def FromList(l):
        m = Matrix(len(l), len(l[0]))
        for rownum, row in enumerate(l):
            for colnum, element in enumerate(row):
                m[rownum][colnum] = element
        return m

    @staticmethod
    def FromString(s, rowsep=None, colsep=None, parser=fractions.Fraction):
        rows = s.strip().split(rowsep) if rowsep else s.strip().splitlines()
        m = Matrix(len(rows), len(rows[0].split(colsep)))
        for rownum, row in enumerate(rows):
            for colnum, element in enumerate(row.split(colsep)):
                m[rownum][colnum] = parser(element)
        return m
    @staticmethod
    def Identity(n):
        m = Matrix(n, n)
        for i in range(n):
            m[i][i] = 1
        return m

def _equals(a, b, delta):
    if delta:
        return abs(a - b) <= delta
    else:
        return a == b

def _get_row_echelon_form(matrix, mirror=None):
    m = matrix.copy()
    mirror = mirror.copy() if mirror else None
    det_multiplier = 1
    
    # Start with the top row and work downwards.
    for top_row in range(m.nrows):

        found = False
        for col in range(m.ncols):
            for row in range(top_row, m.nrows):
                if m[row][col] != 0:
                    found = True
                    break
            if found:
                break
        if not found:
            break

        if m[top_row][col] == 0:
            m.rowop_swap(top_row, row)
            det_multiplier *= -1
            if mirror:
                mirror.rowop_swap(top_row, row)

        if m[top_row][col] != 1:
            multiplier = 1 / m[top_row][col]
            m.rowop_multiply(top_row, multiplier)
            m[top_row][col] = 1 # assign directly in case of rounding errors
            det_multiplier *= multiplier
            if mirror:
                mirror.rowop_multiply(top_row, multiplier)

        # Make all entries below the leading '1' zero.
        for row in range(top_row + 1, m.nrows):
            if m[row][col] != 0:
                multiplier = -m[row][col]
                m.rowop_add(row, multiplier, top_row)
                if mirror:
                    mirror.rowop_add(row, multiplier, top_row)

    return m, mirror, det_multiplier

def _get_reduced_row_echelon_form(matrix, mirror=None):

    m, mirror, ignore = _get_row_echelon_form(matrix, mirror)

    for last_row in range(m.nrows - 1, 0, -1):
        for col in range(m.ncols):
            if m[last_row][col] == 1:
                for row in range(last_row):
                    if m[row][col] != 0:
                        multiplier = -m[row][col]
                        m.rowop_add(row, multiplier, last_row)
                        if mirror:
                            mirror.rowop_add(row, multiplier, last_row)
                break

    return m, mirror
