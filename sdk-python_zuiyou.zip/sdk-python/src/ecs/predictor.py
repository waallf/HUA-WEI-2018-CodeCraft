#coding=utf-8
import math
# from draw_predict_pic import Draw
from collections import Counter
from inputdata import Read_Input_file
from ZIYUAN_alloction import alocti_ziyuan
from xingqiyuce import xingqiyuce
from GOOD import easy_pre
from Markov import Markov
from DANBO import Y_C
from Mo_ni_th import tuihuo
from out_put_txt import output_writer
def predict_vm(ecsDataPath, inputFilePath,resultFilePath,dict_k,threshold):
    # Do your work from here#
    all_hat =[]
    all_hat_name = []
    all_hat_limit = []
    predict_dic_flavor={}
    F_num_less_eight = []
    hread1 =  10
    hread2 = 30
    guige, flavor_name, cpu_or_mem, label_Mat,long_time,start_weekday,S_T_WEEK = Read_Input_file(ecsDataPath,
                                                                                                           inputFilePath,
                                                                                                           threshold)
    if cpu_or_mem =="CPU":
        o_1 = 0
    else:
        o_1 = 1
    for index, f_name_n in enumerate(flavor_name):
        mem_g = 1024
        F_name = flavor_name.values()[index]
        F_cpu_or_mem = int(F_name[o_1] if not o_1 else F_name[o_1] / mem_g)
        cpu_or_mem_limit = int(F_name[1 - o_1] if o_1 else F_name[1-o_1] / mem_g)
        labelMat = label_Mat[index]
        dateMat = [i for i, _ in enumerate(label_Mat[index])]
        testMat = [i + len(dateMat) for i in range(long_time)]


        # yhat = create_result(testMat, dateMat, labelMat, k)
        #
        ll = labelMat[:]
        P_re = Markov(ll,long_time)
        P_re = xingqiyuce(start_weekday,ll,S_T_WEEK,long_time)
        k = 0.3
        yhat = easy_pre(labelMat, long_time)
        P_re = int(yhat)
        if f_name_n =="flavor1":
            P_re+=3
        if f_name_n == "flavor11":
            P_re += 4
        if f_name_n =="flavor12"or  f_name_n =="flavor13"or  f_name_n =="flavor14"or  f_name_n =="flavor15":
            P_re -=1
            if P_re < 0:
                P_re = 0

        if P_re !=0 :
            all_hat.extend([F_cpu_or_mem] * P_re)
            all_hat_limit.extend([cpu_or_mem_limit] * P_re)
            all_hat_name.extend([f_name_n] * P_re)
        if int(f_name_n[6:]) < 8:
            F_num_less_eight.append(f_name_n)
        predict_dic_flavor[f_name_n] = P_re  
    result, delet, ziyuanliyong = alocti_ziyuan(o_1, guige[o_1], guige[1 - o_1], all_hat, all_hat_limit,
                                            all_hat_name)

    L_add_eight = [0] * len(F_num_less_eight)
    best_list_add_eight = L_add_eight[:]
    print(len(F_num_less_eight))
    B_liy = 0
    best_result = []
    orig_all_hat = all_hat[:]
    orig_all_hat_limit = all_hat_limit[:]
    orig_all_hat_name = all_hat_name[:]
    orig_pre_dic = predict_dic_flavor.copy()
    four_number = 4
    for i in range(four_number**len(F_num_less_eight)):
        t =i
        all_hat = orig_all_hat[:]
        all_hat_limit = orig_all_hat_limit[:]
        all_hat_name = orig_all_hat_name[:]
        predict_dic_flavor = orig_pre_dic.copy()
        for j in range(len(F_num_less_eight)):
            L_add_eight[j] = t % four_number
            t = t/four_number
        for list_index,n in enumerate(L_add_eight):
            predict_dic_flavor[F_num_less_eight[list_index]] = predict_dic_flavor[F_num_less_eight[list_index]] + n
            F_name = flavor_name[F_num_less_eight[list_index]]

            F_cpu_or_mem = int(F_name[o_1] if not o_1 else F_name[o_1] / mem_g)
            cpu_or_mem_limit = int(F_name[1 - o_1] if o_1 else F_name[1-o_1] / mem_g)
            f_name_n =F_num_less_eight[list_index]
            if n !=0:
                all_hat.extend([F_cpu_or_mem] * n)
                all_hat_limit.extend([cpu_or_mem_limit] * n)
                all_hat_name.extend([f_name_n] * n)
        result_xz,delet,liyonglv_xz = alocti_ziyuan(o_1, guige[o_1], guige[1 - o_1], all_hat,
                                                              all_hat_limit, all_hat_name)

        if liyonglv_xz> B_liy:
            B_liy = liyonglv_xz
            best_result = result_xz[:]
            best_pre = predict_dic_flavor.copy()
            best_all_hat = all_hat[:]
            best_list_add_eight = L_add_eight[:]
    print("B_liy", B_liy)
    number = 0.02
    all_name = 10
    if  (B_liy - ziyuanliyong < number) and sum(best_list_add_eight)<all_name:
        best_result = result[:]
        best_pre = orig_pre_dic.copy()
        best_all_hat = orig_all_hat[:]

    all_flavor = len(best_all_hat)
    need_xuniji_num = len(best_result)
    output_writer(all_flavor,best_pre,best_result,need_xuniji_num,resultFilePath)

if __name__ == "__main__":
    threshold =2
    k = 6
    predict_vm("TrainData_2015.1.1_2015.5.19.txt","input_5flavors_cpu_7days.txt","out_put_4.txt",k,threshold)
