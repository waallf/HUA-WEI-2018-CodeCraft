#coding=utf-8

import math
def xingqiyuce(start_weekday,labelMat,S_T_weekday,long_Time):
    week_dict = {}
    predict= 0
    for j in range(7):
        weekday = (start_weekday + j) % 7
        weekday = str(weekday)
        week_dict[weekday] = list(labelMat[i] for i in range(j, len(labelMat),7))
    for i in range(long_Time):
        need_pre_week = (S_T_weekday + i) %7
        start_weeneed_pre_weekkday = str(need_pre_week)
        s = week_dict[start_weeneed_pre_weekkday]
        predict += 1.5 *(week_dict[start_weeneed_pre_weekkday][-1] *1+week_dict[start_weeneed_pre_weekkday][-2] *0+week_dict[start_weeneed_pre_weekkday][-3] *0)+1
    return int(predict)
