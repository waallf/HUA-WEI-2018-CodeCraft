## Predict stock with LSTM

本代码参考自博主路一瓢的博文：

[Tensorflow实例：利用LSTM预测股票每日最高价（一）](http://blog.csdn.net/mylove0414/article/details/55805974)

[Tensorflow实例：利用LSTM预测股票每日最高价（二）](http://blog.csdn.net/mylove0414/article/details/56969181)

注：本文代码是在博主路一瓢代码的基础上修改了一些小bug，仅学习之用，非常感谢博主路一瓢，若涉及版权问题等，请指正，必立马删除。
